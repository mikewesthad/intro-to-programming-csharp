﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week4_TriviaGame
{
    class Player
    {
        public string Name;
        public int Score = 0;

        public Player(string name)
        {
            Name = name;
        }
    }
}
